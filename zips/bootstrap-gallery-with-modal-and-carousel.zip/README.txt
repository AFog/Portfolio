A Pen created at CodePen.io. You can find this one at http://codepen.io/webcane/pen/lHGJf.

 Example of responsive image thumbnail grid. 
Each image give id to populate the Bootstrap Modal with filtered images for the hidden images repository. 
Navigate gallery images inside modal using the Carousel.